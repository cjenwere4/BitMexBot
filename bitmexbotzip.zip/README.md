# BitMex Trader Sentiment Bot

A Python script that calculates current sentiment of traders on BitMex. Trader sentiment is posted to the chatbox once every 4 minutes and a complete summary is posted once every hour. Script makes use of BitMex API for chatbox data and chatbox access. Sentiment is judged and calculated via certain key words and makes use of the NLP library, TextBlob for more accurate results.
